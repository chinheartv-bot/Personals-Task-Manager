<?php
/**
 * ============================================================================
 * FILE: routes/web.php
 * ============================================================================
 * WHERE TO PUT THIS:
 *   taskmanager/routes/web.php
 *   (this file ALREADY EXISTS in a fresh Laravel install with some default
 *    sample code — REPLACE the entire contents of that existing file with
 *    the code below; do not create a second file)
 *
 * WHAT IT DOES / WHERE IT FITS IN THE FLOW:
 *   This is where every URL a user visits gets matched to a Controller
 *   method. It's the very first stop for any request.
 *   Flow: Browser request -> [THIS ROUTE FILE] -> Controller -> ...
 * ============================================================================
 */

use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;

// Redirect root to the task list
Route::redirect('/', '/tasks');

// Full CRUD for tasks (index, create, store, edit, update, destroy)
Route::resource('tasks', TaskController::class)->except(['show']);

// Extra route: quick status toggle (Pending <-> Completed)
Route::patch('/tasks/{task}/status', [TaskController::class, 'updateStatus'])
    ->name('tasks.status');
