<!--
============================================================================
FILE: resources/views/layouts/app.blade.php
============================================================================
WHERE TO PUT THIS:
  taskmanager/resources/views/layouts/app.blade.php
  ("resources/views" exists; you need to CREATE a new "layouts" folder
   inside it, then this file inside that folder)

WHAT IT DOES / WHERE IT FITS IN THE FLOW:
  This is the shared page shell (navbar + <head> + CSS link) that every
  other Blade view "extends" with @extends('layouts.app'), so you don't
  repeat the navbar/HTML skeleton on every page.
  Flow: Controller returns a view -> that view extends [THIS LAYOUT]
============================================================================
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Personal Task Manager')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>

    <nav class="navbar">
        <h1>📝 Personal Task Manager</h1>
        <a href="{{ route('tasks.create') }}" class="btn-add">+ Add Task</a>
    </nav>

    <div class="container">
        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @yield('content')
    </div>

</body>
</html>
