<?php
/**
 * ============================================================================
 * FILE: database/migrations/2026_09_22_000000_create_tasks_table.php
 * ============================================================================
 * WHERE TO PUT THIS:
 *   taskmanager/database/migrations/2026_09_22_000000_create_tasks_table.php
 *   (the "database/migrations" folder already exists — this is a NEW file
 *    you add there; keep the date prefix, or run `php artisan make:migration
 *    create_tasks_table` and paste the up()/down() code below into the
 *    generated file instead)
 *
 * WHAT IT DOES / WHERE IT FITS IN THE FLOW:
 *   This defines the actual "tasks" table and its columns in the database.
 *   Running `php artisan migrate` executes this file and creates the table.
 *   Flow: THIS MIGRATION builds the Database -> Model reads/writes it
 * ============================================================================
 */

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->string('task_name');
            $table->text('description')->nullable();
            $table->enum('status', ['Pending', 'Completed'])->default('Pending');
            $table->date('due_date')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tasks');
    }
};
