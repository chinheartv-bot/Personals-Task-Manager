{{--
============================================================================
FILE: resources/views/tasks/index.blade.php
============================================================================
WHERE TO PUT THIS:
  taskmanager/resources/views/tasks/index.blade.php
  ("resources/views" exists; CREATE a new "tasks" folder inside it, then
   this file inside that folder)

WHAT IT DOES / WHERE IT FITS IN THE FLOW:
  This is the task LIST / dashboard page. TaskController@index loads all
  tasks from the database and hands them to this view as $tasks, which
  loops over them with @foreach to build the table.
  Flow: GET /tasks -> TaskController@index -> [THIS VIEW] -> browser
============================================================================
--}}
@extends('layouts.app')

@section('title', 'My Tasks')

@section('content')

    @php
        $total = $tasks->count();
        $completed = $tasks->where('status', 'Completed')->count();
        $pending = $tasks->where('status', 'Pending')->count();
    @endphp

    <div class="dashboard-stats">
        <div class="stat-box">
            <div class="num">{{ $total }}</div>
            <div class="label">Total Tasks</div>
        </div>
        <div class="stat-box">
            <div class="num">{{ $pending }}</div>
            <div class="label">Pending</div>
        </div>
        <div class="stat-box">
            <div class="num">{{ $completed }}</div>
            <div class="label">Completed</div>
        </div>
    </div>

    <div class="card">
        @if ($tasks->isEmpty())
            <div class="empty-state">
                <p>No tasks yet. Click <strong>"+ Add Task"</strong> to create your first one.</p>
            </div>
        @else
            <table>
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($tasks as $task)
                        <tr>
                            <td>{{ $task->task_name }}</td>
                            <td>{{ Str::limit($task->description, 60) }}</td>
                            <td>
                                @if ($task->due_date)
                                    <span class="{{ $task->due_date->isPast() && $task->status !== 'Completed' ? 'due-soon' : '' }}">
                                        {{ $task->due_date->format('M d, Y') }}
                                    </span>
                                @else
                                    <span style="color:#9ca3af;">—</span>
                                @endif
                            </td>
                            <td>
                                <span class="badge {{ $task->status === 'Completed' ? 'badge-completed' : 'badge-pending' }}">
                                    {{ $task->status }}
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <form class="inline" action="{{ route('tasks.status', $task) }}" method="POST">
                                        @csrf
                                        @method('PATCH')
                                        <button type="submit" class="btn btn-toggle">
                                            Mark as {{ $task->status === 'Pending' ? 'Completed' : 'Pending' }}
                                        </button>
                                    </form>

                                    <a href="{{ route('tasks.edit', $task) }}" class="btn btn-outline">Edit</a>

                                    <form class="inline" action="{{ route('tasks.destroy', $task) }}" method="POST"
                                          onsubmit="return confirm('Delete this task?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>

@endsection
