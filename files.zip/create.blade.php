{{--
============================================================================
FILE: resources/views/tasks/create.blade.php
============================================================================
WHERE TO PUT THIS:
  taskmanager/resources/views/tasks/create.blade.php
  (goes in the same "tasks" folder as index.blade.php and edit.blade.php)

WHAT IT DOES / WHERE IT FITS IN THE FLOW:
  This is the "Add Task" form page. Submitting it POSTs to
  route('tasks.store'), which TaskController@store handles.
  Flow: GET /tasks/create -> TaskController@create -> [THIS VIEW]
        -> user submits form -> POST /tasks -> TaskController@store
============================================================================
--}}
@extends('layouts.app')

@section('title', 'Add Task')

@section('content')

    <div class="card form-card">
        <h2>Add New Task</h2>

        <form action="{{ route('tasks.store') }}" method="POST">
            @csrf

            <div class="form-group">
                <label for="task_name">Task Name</label>
                <input type="text" id="task_name" name="task_name" value="{{ old('task_name') }}" required>
                @error('task_name')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description">{{ old('description') }}</textarea>
                @error('description')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="date" id="due_date" name="due_date" value="{{ old('due_date') }}">
                @error('due_date')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="Pending" {{ old('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
                    <option value="Completed" {{ old('status') == 'Completed' ? 'selected' : '' }}>Completed</option>
                </select>
                @error('status')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Save Task</button>
                <a href="{{ route('tasks.index') }}" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>

@endsection
