# Personal Task Manager

Project Code: WST21-PM-2026-SF
Student Name:
Course & Year:
Database Used: MySQL

## Features
- Add Task
- View Tasks
- Edit Task
- Delete Task
- Update Status

## About This Project
A simple Personal Task Manager built with Laravel, following the
Routes → Controller → Model → Database → Blade flow. Users can create,
view, edit, delete tasks, and toggle a task's status between **Pending**
and **Completed** from a dashboard-style task list.

## Tech Stack
- Laravel (PHP framework)
- Blade templating
- MySQL database
- Plain CSS for styling (no external framework)

## How It Works
- **routes/web.php** – defines all the URLs for the app (task list, create,
  edit, delete, and a status-toggle route) and points them to
  `TaskController`.
- **app/Http/Controllers/TaskController.php** – handles the logic for each
  action: fetching tasks, validating and saving form input, updating
  records, deleting records, and flipping a task's status.
- **app/Models/Task.php** – the Eloquent model that maps to the `tasks`
  table and defines which fields can be mass-assigned.
- **database/migrations/..._create_tasks_table.php** – defines the `tasks`
  table schema (`task_name`, `description`, `status`, `due_date`).
- **resources/views/tasks/** – Blade views for the task list (`index`),
  the add-task form (`create`), and the edit-task form (`edit`), all
  extending a shared `layouts/app.blade.php` layout.

## Setup Instructions

1. Clone this repository:
   ```
   git clone <your-repo-url>
   cd taskmanager
   ```
2. Install dependencies:
   ```
   composer install
   ```
3. Copy the environment file and generate an app key:
   ```
   cp .env.example .env
   php artisan key:generate
   ```
4. Configure your database in `.env`:
   ```
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=taskmanager
   DB_USERNAME=root
   DB_PASSWORD=
   ```
5. Create the database (e.g. `taskmanager`) in MySQL, then run the
   migration:
   ```
   php artisan migrate
   ```
6. Start the local server:
   ```
   php artisan serve
   ```
7. Visit `http://127.0.0.1:8000` in your browser.

## Screenshots
(Add screenshots of your dashboard, add-task form, and edit-task form here.)
