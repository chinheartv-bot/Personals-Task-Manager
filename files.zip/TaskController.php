<?php
/**
 * ============================================================================
 * FILE: app/Http/Controllers/TaskController.php
 * ============================================================================
 * WHERE TO PUT THIS:
 *   taskmanager/app/Http/Controllers/TaskController.php
 *   (the "app/Http/Controllers" folder already exists with a default
 *    Controller.php — TaskController.php is a NEW file you add next to it;
 *    or run `php artisan make:controller TaskController` and paste these
 *    methods into the generated file instead)
 *
 * WHAT IT DOES / WHERE IT FITS IN THE FLOW:
 *   This is the Controller. Every route below points to one of its methods.
 *   It receives the request, validates input, talks to the Task Model to
 *   read/write the database, then loads a Blade view (or redirects).
 *   Flow: Route -> [THIS CONTROLLER] -> Model -> Database -> Blade view
 * ============================================================================
 */

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class TaskController extends Controller
{
    /**
     * Display a listing of all tasks.
     */
    public function index(): View
    {
        $tasks = Task::orderBy('due_date', 'asc')->get();

        return view('tasks.index', compact('tasks'));
    }

    /**
     * Show the form for creating a new task.
     */
    public function create(): View
    {
        return view('tasks.create');
    }

    /**
     * Store a newly created task in the database.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'task_name'   => 'required|string|max:255',
            'description' => 'nullable|string',
            'status'      => 'required|in:Pending,Completed',
            'due_date'    => 'nullable|date',
        ]);

        Task::create($validated);

        return redirect()->route('tasks.index')
            ->with('success', 'Task added successfully.');
    }

    /**
     * Show the form for editing the specified task.
     */
    public function edit(Task $task): View
    {
        return view('tasks.edit', compact('task'));
    }

    /**
     * Update the specified task in the database.
     */
    public function update(Request $request, Task $task): RedirectResponse
    {
        $validated = $request->validate([
            'task_name'   => 'required|string|max:255',
            'description' => 'nullable|string',
            'status'      => 'required|in:Pending,Completed',
            'due_date'    => 'nullable|date',
        ]);

        $task->update($validated);

        return redirect()->route('tasks.index')
            ->with('success', 'Task updated successfully.');
    }

    /**
     * Remove the specified task from the database.
     */
    public function destroy(Task $task): RedirectResponse
    {
        $task->delete();

        return redirect()->route('tasks.index')
            ->with('success', 'Task deleted successfully.');
    }

    /**
     * Quickly toggle a task's status between Pending and Completed.
     */
    public function updateStatus(Task $task): RedirectResponse
    {
        $task->status = $task->status === 'Pending' ? 'Completed' : 'Pending';
        $task->save();

        return redirect()->route('tasks.index')
            ->with('success', 'Task status updated.');
    }
}
