{{--
============================================================================
FILE: resources/views/tasks/edit.blade.php
============================================================================
WHERE TO PUT THIS:
  taskmanager/resources/views/tasks/edit.blade.php
  (goes in the same "tasks" folder as index.blade.php and create.blade.php)

WHAT IT DOES / WHERE IT FITS IN THE FLOW:
  This is the "Edit Task" form page, pre-filled with one task's existing
  values. Submitting it PUTs to route('tasks.update', $task), which
  TaskController@update handles.
  Flow: GET /tasks/{task}/edit -> TaskController@edit -> [THIS VIEW]
        -> user submits form -> PUT /tasks/{task} -> TaskController@update
============================================================================
--}}
@extends('layouts.app')

@section('title', 'Edit Task')

@section('content')

    <div class="card form-card">
        <h2>Edit Task</h2>

        <form action="{{ route('tasks.update', $task) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="task_name">Task Name</label>
                <input type="text" id="task_name" name="task_name"
                       value="{{ old('task_name', $task->task_name) }}" required>
                @error('task_name')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description">{{ old('description', $task->description) }}</textarea>
                @error('description')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="date" id="due_date" name="due_date"
                       value="{{ old('due_date', optional($task->due_date)->format('Y-m-d')) }}">
                @error('due_date')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="Pending" {{ old('status', $task->status) == 'Pending' ? 'selected' : '' }}>Pending</option>
                    <option value="Completed" {{ old('status', $task->status) == 'Completed' ? 'selected' : '' }}>Completed</option>
                </select>
                @error('status')
                    <div class="error-text">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Update Task</button>
                <a href="{{ route('tasks.index') }}" class="btn btn-outline">Cancel</a>
            </div>
        </form>
    </div>

@endsection
