# Complete Flow — How Everything Connects

This walks through exactly what happens, file by file, for each feature.
Read this alongside the labeled comments at the top of each file.

## The file tree (full paths)

```
taskmanager/
├── app/
│   ├── Http/
│   │   └── Controllers/
│   │       └── TaskController.php          (NEW file you add)
│   └── Models/
│       └── Task.php                        (NEW file you add)
├── database/
│   └── migrations/
│       └── 2026_09_22_000000_create_tasks_table.php   (NEW file you add)
├── public/
│   └── css/
│       └── app.css                         (NEW file you add)
├── resources/
│   └── views/
│       ├── layouts/
│       │   └── app.blade.php               (NEW file you add)
│       └── tasks/
│           ├── index.blade.php             (NEW file you add)
│           ├── create.blade.php            (NEW file you add)
│           └── edit.blade.php              (NEW file you add)
├── routes/
│   └── web.php                             (EXISTS — replace its contents)
└── README.md                               (EXISTS — replace its contents)
```

`app/`, `database/migrations/`, `public/`, `resources/views/`, and `routes/`
already exist after `composer create-project laravel/laravel taskmanager`.
You are adding new files inside them (and creating the `layouts/` and
`tasks/` subfolders), except `routes/web.php` and `README.md`, which
already exist and you overwrite.

## One-time setup flow

1. `composer create-project laravel/laravel taskmanager` — scaffolds the
   base Laravel app (this creates all the folders above, empty).
2. Copy in the files listed above, into the exact paths shown.
3. `cp .env.example .env` then `php artisan key:generate`.
4. Edit `.env` — set `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` for your
   MySQL database.
5. Create that database in MySQL (e.g. `CREATE DATABASE taskmanager;`).
6. `php artisan migrate` — this runs
   `database/migrations/..._create_tasks_table.php`, which creates the
   `tasks` table with columns `id, task_name, description, status,
   due_date, created_at, updated_at`.
7. `php artisan serve` — starts the app at `http://127.0.0.1:8000`.

## Request flow for each feature

### View Tasks (the dashboard)
1. Browser requests `GET /tasks`.
2. `routes/web.php` matches this to `TaskController@index`.
3. `TaskController@index` runs `Task::orderBy('due_date')->get()` —
   this uses the `Task` Model (`app/Models/Task.php`) to query the
   `tasks` table in the database.
4. The results are passed as `$tasks` to
   `resources/views/tasks/index.blade.php`.
5. That view `@extends('layouts.app')` (the shared navbar/HTML shell)
   and loops over `$tasks` with `@foreach` to render the table.

### Add Task
1. Browser requests `GET /tasks/create` → `TaskController@create` →
   returns `resources/views/tasks/create.blade.php` (the empty form).
2. User fills the form and submits → browser sends
   `POST /tasks` with the form data.
3. `routes/web.php` matches this to `TaskController@store`.
4. `TaskController@store` validates the input, then calls
   `Task::create($validated)` — the Model inserts a new row into the
   `tasks` table.
5. Controller redirects back to `route('tasks.index')`, which re-runs
   the "View Tasks" flow above, now showing the new task.

### Edit Task
1. Browser requests `GET /tasks/{id}/edit` → `TaskController@edit` →
   Laravel automatically loads that one `Task` (route-model binding) →
   returns `resources/views/tasks/edit.blade.php`, pre-filled with the
   task's current values.
2. User changes fields and submits → browser sends
   `PUT /tasks/{id}` with the form data.
3. `routes/web.php` matches this to `TaskController@update`.
4. `TaskController@update` validates the input, then calls
   `$task->update($validated)` — the Model updates that row.
5. Controller redirects back to `route('tasks.index')`.

### Delete Task
1. On the task list, the Delete button submits a form with
   `DELETE /tasks/{id}`.
2. `routes/web.php` matches this to `TaskController@destroy`.
3. `TaskController@destroy` calls `$task->delete()` — the Model removes
   that row from the `tasks` table.
4. Controller redirects back to `route('tasks.index')`.

### Update Status (Pending ↔ Completed)
1. On the task list, "Mark as Completed/Pending" submits a form with
   `PATCH /tasks/{id}/status`.
2. `routes/web.php` matches this to `TaskController@updateStatus`
   (this is the one extra custom route, added alongside the standard
   `Route::resource` line).
3. `TaskController@updateStatus` flips `$task->status` between
   `'Pending'` and `'Completed'` and saves it.
4. Controller redirects back to `route('tasks.index')`.

## Summary: Routes → Controller → Model → Database → Blade

```
Browser
   |
   v
routes/web.php  ───────────────►  which Controller method runs?
   |
   v
TaskController.php  ────────────►  handles the request, validates input
   |
   v
Task.php (Model)  ──────────────►  talks to the database (tasks table)
   |
   v
MySQL "tasks" table  (created by the migration file)
   |
   v
TaskController.php  ────────────►  loads a Blade view, or redirects
   |
   v
resources/views/tasks/*.blade.php  ──►  extends layouts/app.blade.php
   |                                     (which links public/css/app.css)
   v
Browser renders the page
```
