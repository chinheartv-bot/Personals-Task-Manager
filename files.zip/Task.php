<?php
/**
 * ============================================================================
 * FILE: app/Models/Task.php
 * ============================================================================
 * WHERE TO PUT THIS:
 *   taskmanager/app/Models/Task.php
 *   (the "app/Models" folder already exists in a fresh Laravel install —
 *    Task.php is not there by default, so this is a NEW file you add)
 *
 * WHAT IT DOES / WHERE IT FITS IN THE FLOW:
 *   This is the Model. It represents one row of the "tasks" table and is
 *   how the Controller talks to the database (Task::all(), Task::create(),
 *   $task->update(), $task->delete(), etc.) without writing raw SQL.
 *   Flow: Route -> Controller -> [THIS MODEL] -> Database -> back to Controller
 * ============================================================================
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'task_name',
        'description',
        'status',
        'due_date',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'due_date' => 'date',
    ];
}
